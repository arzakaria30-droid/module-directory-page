export interface Module {
  id: number
  title: string
  description: string
  teacher: string
}
